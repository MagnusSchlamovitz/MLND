1. See CapstoneProject.pdf for report 
2. "imgs" folder contains train and test data (dataset can be obtained at 
https://www.kaggle.com/c/state-farm-distracted-driver-detection/data) (can't incli=ude in the submission because the file is too large)

3. Source code in py sublime files "dataanalysis", "capstone", "outputplotting" 
